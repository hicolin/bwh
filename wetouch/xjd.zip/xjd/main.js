import app from './app.ui'

let options = {
  app: app
}
ui.start(options)